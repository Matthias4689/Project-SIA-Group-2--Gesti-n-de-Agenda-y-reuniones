/**
 *
 * @author Javier Donetch, Luciano Fredes y Matías Romero
 */

import java.util.HashMap;
import java.util.Map;
import java.text.DecimalFormat;

// Clase Persona
public class Persona {
    // Atributos de Persona
    private String nombre;
    private String email;
    // Inicializa el mapa de reuniones
    private Map<String, Reunion> reuniones;

    // Constructor de Persona
    public Persona(String nombre, String email) {
        // Inicializa los atributos de la persona
        this.nombre = nombre;
        this.email = email;
         // Inicialización del HashMap
        this.reuniones = new HashMap<String, Reunion>();
    }

    // Getters y Setters Persona
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

  // Sobrecarga de método para agregar una reunión con la hora representada como un int
  public void agregarReunion(Reunion reunion) {
      reuniones.put(reunion.getNombre(), reunion);
  }

  // Sobrecarga de método para agregar una reunión con la hora representada como un double
  public void agregarReunion(String nombre, String lugar, String fecha, double hora) {
      Reunion reunion = new Reunion(nombre, lugar, fecha, hora);
      reuniones.put(nombre, reunion);
  }

  // Sobrecarga de método para agregar una reunión con la hora representada como un int
  public void agregarReunion(String nombre, String lugar, String fecha, int hora, int minuto) {
      double horaDecimal = hora + (minuto / 60.0);
      Reunion reunion = new Reunion(nombre, lugar, fecha, horaDecimal);
      reuniones.put(nombre, reunion);
  }

    // Método para obtener información de todas las reuniones de la persona
    public String getInfoReuniones() {
        StringBuilder infoReuniones = new StringBuilder();
        for (Reunion reunion : reuniones.values()) {
            infoReuniones.append(reunion.getInfoReunion()).append("\n");
        }
        return infoReuniones.toString();
    }

    // Clase anidada Reunion
    public static class Reunion {
        // Atributos de Reunion
        private String nombre;
        private String lugar;
        private String fecha;
        private double hora;

        // Constructor de Reunion
        public Reunion(String nombre, String lugar, String fecha, double hora) {
            this.nombre = nombre;
            this.lugar = lugar;
            this.fecha = fecha;
            this.hora = hora;
        }

        // Getters y Setters de Reunion
        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getLugar() {
            return lugar;
        }

        public void setLugar(String lugar) {
            this.lugar = lugar;
        }

        public String getFecha() {
            return fecha;
        }

        public void setFecha(String fecha) {
            this.fecha = fecha;
        }

        public double getHora() {
            return hora;
        }

        public void setHora(double hora) {
            this.hora = hora;
        }

        // Método para obtener información de la reunión
        public String getInfoReunion() {
          DecimalFormat df = new DecimalFormat("#0.00");
          return  "\n" + "" + nombre + "\n" + "Lugar: " + lugar + "\n" + "Fecha: " + fecha + "\n" + "Hora: " + df.format(hora);

        }
    }
}