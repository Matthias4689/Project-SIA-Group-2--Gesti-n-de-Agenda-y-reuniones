/**
 *
 * @author Javier Donetch, Luciano Fredes y Matías Romero
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in); // Crear un objeto Scanner

        
        int opcion;
        //Creacion lista de personas
        List<Persona> personas = new ArrayList<Persona>();

        // Creación de Personas
        Persona persona1 = new Persona("Juan", "juan@example.com");
        Persona persona2 = new Persona("María", "maria@example.com");
        personas.add(persona1);
        personas.add(persona2);

        // Creación de algunas reuniones y agregación a la lista de reuniones de la persona1 y persona2
        Persona.Reunion reunion1 = new Persona.Reunion("Reunion Ventas","Sala de Conferencias", "2024-03-20", 10);
        Persona.Reunion reunion2 = new Persona.Reunion("Reunion Jefe","Oficina", "2024-03-22", 15.5);
        persona1.agregarReunion(reunion1);
        persona1.agregarReunion(reunion2);
        
        persona2.agregarReunion(reunion1);
        persona2.agregarReunion(reunion2);
      
        System.out.println("Bienvenido al sistema de agenda y reuniones\n\n");
    
        do{
            // Menu
            System.out.println("Menu\n");
            System.out.println("1. Agregar Persona");
            System.out.println("2. Agregar Reunion");
            System.out.println("3. Ver Reunion");
            System.out.println("4. Salir");
            System.out.println("Ingrese una opcion: ");
            opcion = scanner.nextInt(); // Leer la opción del usuario
            System.out.println("");
            scanner.nextLine(); // Consumir el salto de línea pendiente después de leer el entero

            switch(opcion){
                case 1:
                    // Agregar Persona
                    System.out.println("Ingrese el nombre de la persona:");
                    String nombre = scanner.nextLine(); // Leer el nombre de la persona
                    System.out.println("Ingrese el correo electrónico de la persona:");
                    String email = scanner.nextLine(); // Leer el correo electrónico de la persona
                    personas.add(new Persona(nombre, email));
                    System.out.println("Persona creada correctamente.");
                    System.out.println("");
                    break;
                case 2:
                    // Agregar Reunion
                    System.out.println("Seleccione la persona a la que desea agregar la reunión:");
                    for (int i = 0; i < personas.size(); i++) {
                        System.out.println((i + 1) + ". " + personas.get(i).getNombre());
                    }
                    // Seleccionar persona
                    // Se intuye que una persona no puede tener una reunion sola.
                    System.out.println("Ingrese una opcion: ");
                    int indicePersonaAgregar = scanner.nextInt() - 1;
                    System.out.println("");
                    scanner.nextLine(); // Consumir el salto de línea pendiente después de leer el entero

                    System.out.println("Ingrese el nombre de la reunión:");
                    String nombreReunion = scanner.nextLine();
                    System.out.println("Ingrese el lugar:");
                    String lugar = scanner.nextLine();
                    System.out.println("Ingrese la fecha (YYYY-MM-DD):");
                    String fecha = scanner.nextLine();
                    System.out.println("¿La hora será representada como un entero (1) o un double (2)?");
                    System.out.println("Ingrese una opcion: ");
                    int opcionHora = scanner.nextInt();
                    System.out.println("");
                    scanner.nextLine(); // Consumir el salto de línea pendiente después de leer el entero

                    switch (opcionHora) {
                        case 1:
                            System.out.println("Ingrese la hora:");
                            int horaEntera = scanner.nextInt();
                            System.out.println("¿Desea agregarle minutos a la hora? (1. Sí / 2. No)");
                            System.out.println("Ingrese una opcion: ");
                            int opcionMinutos = scanner.nextInt();
                            System.out.println("");
                            scanner.nextLine(); // Consumir el salto de línea pendiente después de leer el entero

                            if (opcionMinutos == 1){
                                System.out.println("Ingrese los minutos:");
                                int minutos = scanner.nextInt();
                                personas.get(indicePersonaAgregar).agregarReunion(nombreReunion, lugar, fecha, horaEntera, minutos);
                            }
                            else{
                                personas.get(indicePersonaAgregar).agregarReunion(nombreReunion, lugar, fecha, horaEntera);
                            }
                            break;
                        case 2:
                            System.out.println("Ingrese la hora (en formato decimal, por ejemplo 14,5 para 14:50 y con máximo 2 decimales):");
                            double horaDecimal = scanner.nextDouble();
                            personas.get(indicePersonaAgregar).agregarReunion(nombreReunion, lugar, fecha, horaDecimal);
                            break;
                    }
                    System.out.println("Reunión agregada correctamente.");
                    System.out.println("");
                    break;
                case 3:
                    // Ver Reunion
                    System.out.println("Seleccione la persona de la que desea ver las reuniones:");
                    for (int i = 0; i < personas.size(); i++) {
                        System.out.println((i + 1) + ". " + personas.get(i).getNombre());
                    }
                    System.out.println("Ingrese una opcion: ");
                    int indicePersonaVer = scanner.nextInt() - 1;
                    System.out.println("");
                    scanner.nextLine(); // Consumir el salto de línea pendiente después de leer el entero

                    System.out.println("Información de las Reuniones de " + personas.get(indicePersonaVer).getNombre() + ":\n" + personas.get(indicePersonaVer).getInfoReuniones());
                    System.out.println("");
                    break;
            }
        } while(opcion != 4);
    }
}